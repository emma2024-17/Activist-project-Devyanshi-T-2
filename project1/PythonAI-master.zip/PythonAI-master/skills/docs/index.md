# Subscribe 
To subscribe to the iCal file click here:
[myfile.ics](myfile.ics)

---
