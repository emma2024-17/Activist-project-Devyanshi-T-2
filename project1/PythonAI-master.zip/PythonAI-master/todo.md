# Todo

- [ ] Check Bookworm works ok from a dependency perspective
- [ ] Integrate with Ollama and build a desktop companion robot chassis
- [ ] Change the JSON file to a simpler, easier to read YAML file
- [ ] Improve the documentation - make a mini-tutorial
- [ ] Document each of the Videos in the playlist
- [ ] Create a supporting written tutorial over on [kevsrobots](https://www.kevsrobots.com)
